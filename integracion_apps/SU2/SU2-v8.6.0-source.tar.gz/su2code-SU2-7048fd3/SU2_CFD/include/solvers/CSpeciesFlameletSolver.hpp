/*!
 * \file CSpeciesFlameletSolver.hpp
 * \brief Headers of the CSpeciesFlameletSolver class
 * \author D. Mayer, N. Beishuizen, T. Economon, E. Bunschoten
 * \version 8.6.0 "Harrier"
 *
 * SU2 Project Website: https://su2code.github.io
 *
 * The SU2 Project is maintained by the SU2 Foundation
 * (http://su2foundation.org)
 *
 * Copyright 2012-2026, SU2 Contributors (cf. AUTHORS.md)
 *
 * SU2 is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * SU2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with SU2. If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#include "CSpeciesSolver.hpp"

/*!
 * \class CSpeciesFlameletSolver
 * \brief Main class for defining the flamelet model solver.
 * \author N. Beishuizen
 * \ingroup Scalar_Transport
 */
class CSpeciesFlameletSolver final : public CSpeciesSolver {
 private:
  FluidFlamelet_ParsedOptions flamelet_config_options;
  const su2double default_flame_thickness{1.0};
  su2double global_flame_thickness;
  bool calc_flame_thickness{false};
  bool include_mixture_fraction = false; /*!< \brief include mixture fraction as a controlling variable. */
  /*!< \brief Number of points outside the manifold domain, shared across OpenMP threads so it can be
   *          accumulated atomically and reduced by the master thread alone in Preprocessing. */
  unsigned long n_not_in_domain_local = 0;
  /*!
   * \brief Compute the preconditioner for low-Mach flows.
   * \param[in] geometry - Geometrical definition of the problem.
   * \param[in] solver_container - Container vector with all the solutions.
   * \param[in] config - Definition of the particular problem.
   */
  void SetPreconditioner(CGeometry* geometry, CSolver** solver_container, CConfig* config);

  /*!
   * \brief Generic implementation of the isothermal wall also covering CHT cases,
   * for which the wall temperature is given by GetConjugateHeatVariable.
   */
  void BC_Isothermal_Wall_Generic(CGeometry* geometry, CSolver** solver_container, CNumerics* conv_numerics,
                                  CNumerics* visc_numerics, CConfig* config, unsigned short val_marker,
                                  bool cht_mode = false);

  /*!
   * \brief Reverse look-up to retrieve enthalpy value based on temperature and other controlling variables.
   * \param[in] fluid_model - pointer to flamelet fluid model.
   * \param[in] val_temp - temperature value used for reverse look-up.
   * \param[in] scalar_solution - local scalar solution.
   * \param[in] val_enth_out - pointer to output enthalpy variable.
   * \param[out] Converged - 0 if Newton solver converged, 1 if not.
   */
  unsigned long GetEnthFromTemp(CFluidModel* fluid_model, su2double const val_temp, const su2double* scalar_solution,
                                su2double* val_enth_out);

  /*!
   * \brief Find maximum progress variable value within the manifold for the current solution.
   * \param[in] fluid_model - pointer to flamelet fluid model.
   * \param[in] scalars - local scalar solution.
   * \param[in] T_ignition - ignition temperature - at this temperature, the progress variable is considered burnt.
   * \return - maximum progress variable value within manifold bounds.
   */
  su2double GetBurntProgressVariable(CFluidModel* fluid_model, const su2double* scalars, const su2double T_ignition);

  /*!
   * \brief Retrieve scalar source terms from manifold.
   * \param[in] config - definition of particular problem.
   * \param[in] fluid_model_local - pointer to flamelet fluid model.
   * \param[in] iPoint - node ID.
   * \param[in] scalars - local scalar solution.
   * \param[in] table_source_names - variable names of scalar source terms.
   * \param[in] F - flame thickness correction factor.
   * \return - within manifold bounds (0) or outside manifold bounds (1).
   */
  unsigned long SetScalarSources(const CConfig* config, CFluidModel* fluid_model_local, unsigned long iPoint,
                                 const vector<su2double>& scalars, const su2double F=1.0);

  /*!
   * \brief Retrieve passive look-up data from manifold.
   * \param[in] fluid_model_local - pointer to flamelet fluid model.
   * \param[in] iPoint - node ID.
   * \param[in] scalars - local scalar solution.
   * \return - within manifold bounds (0) or outside manifold bounds (1).
   */
  unsigned long SetScalarLookUps(CFluidModel* fluid_model_local, unsigned long iPoint,
                                 const vector<su2double>& scalars);

  /*!
   * \brief Retrieve the preferential diffusion scalar values from manifold.
   * \param[in] fluid_model_local - pointer to flamelet fluid model.
   * \param[in] iPoint - node ID.
   * \param[in] scalars - local scalar solution.
   * \return - within manifold bounds (0) or outside manifold bounds (1).
   */
  unsigned long SetPreferentialDiffusionScalars(CFluidModel* fluid_model_local,
                                                unsigned long iPoint, const vector<su2double>& scalars);
  
  /*!
   * \brief Calculate correction factor for flame propagation on coarse grids.
   * \param[in] geometry - Geometrical definition of the problem.
   * \param[in] iPoint - node ID.
   * \return - flame thickness correction factor.
   */                                              
  su2double ThickenedFlameCorrection(const CGeometry* geometry, unsigned long iPoint) const;   

  /*!
   * \brief Approximate the minimum flame thickness value used for the thickened flame model.
   * \param[in] geometry - Geometrical definition of the problem.
   * \param[in] solver_container - Container vector with all the solutions.
   * \return - approximate flame thickness value.
   */
  su2double GetOverallFlameThickness(CGeometry* geometry,  CSolver** solver_container) const;

 public:
  /*!
   * \brief Define a Flamelet Generated Manifold species solver.
   * \param[in] geometry - Geometrical definition of the problem.
   * \param[in] config - Definition of the particular problem.
   * \param[in] iMesh - Index of the mesh in multigrid computations.
   */
  CSpeciesFlameletSolver(CGeometry* geometry, CConfig* config, const CSolver* flow_solver, unsigned short iMesh);

  /*!
   * \brief Restart residual and compute gradients.
   * \param[in] geometry - Geometrical definition of the problem.
   * \param[in] solver_container - Container vector with all the solutions.
   * \param[in] config - Definition of the particular problem.
   * \param[in] iMesh - Index of the mesh in multigrid computations.
   * \param[in] iRKStep - Current step of the Runge-Kutta iteration.
   * \param[in] RunTime_EqSystem - System of equations which is going to be solved.
   * \param[in] Output - Boolean to determine whether to print output.
   */
  void Preprocessing(CGeometry* geometry, CSolver** solver_container, CConfig* config, unsigned short iMesh,
                     unsigned short iRKStep, unsigned short RunTime_EqSystem, bool Output) override;

  /*!
   * \brief Set the initial condition for the scalar transport problem.
   * \param[in] geometry - Geometrical definition of the problem.
   * \param[in] solver_container - Container with all the solutions.
   * \param[in] config - Definition of the particular problem.
   * \param[in] ExtIter - External iteration.
   */
  void SetInitialCondition(CGeometry** geometry, CSolver*** solver_container, CConfig* config,
                           unsigned long ExtIter) override;

  /*!
   * \brief Source term computation.
   * \param[in] geometry - Geometrical definition of the problem.
   * \param[in] solver_container - Container vector with all the solutions.
   * \param[in] numerics - Description of the numerical method.
   * \param[in] config - Definition of the particular problem.
   * \param[in] iMesh - Index of the mesh in multigrid computations.
   */
  void Source_Residual(CGeometry* geometry, CSolver** solver_container, CNumerics** numerics_container, CConfig* config,
                       unsigned short iMesh) override;

  /*!
   * \brief Impose the Navier-Stokes wall boundary condition.
   * \param[in] geometry - Geometrical definition of the problem.
   * \param[in] solver_container - Container vector with all the solutions.
   * \param[in] conv_numerics - Description of the numerical method.
   * \param[in] visc_numerics - Description of the numerical method.
   * \param[in] config - Definition of the particular problem.
   * \param[in] val_marker - Surface marker where the boundary condition is applied.
   */
  void BC_Isothermal_Wall(CGeometry* geometry, CSolver** solver_container, CNumerics* conv_numerics,
                          CNumerics* visc_numerics, CConfig* config, unsigned short val_marker) override;

  /*!
   * \brief Impose the heat-flux wall boundary condition on the flamelet enthalpy scalar.
   * When FLAMELET_ENTHALPY_BC= FLOW_MARKERS (default), the heat flux value from MARKER_HEATFLUX
   * is applied as a Neumann boundary condition on the enthalpy scalar H.
   * When FLAMELET_ENTHALPY_BC= SPECIES_MARKERS, use flux/value from MARKER_WALL_SPECIES.
   * \param[in] geometry - Geometrical definition of the problem.
   * \param[in] solver_container - Container vector with all the solutions.
   * \param[in] conv_numerics - Description of the numerical method.
   * \param[in] visc_numerics - Description of the numerical method.
   * \param[in] config - Definition of the particular problem.
   * \param[in] val_marker - Surface marker where the boundary condition is applied.
   */
  void BC_HeatFlux_Wall(CGeometry* geometry, CSolver** solver_container, CNumerics* conv_numerics,
                        CNumerics* visc_numerics, CConfig* config, unsigned short val_marker) override;

  /*!
   * \brief Impose the inlet boundary condition.
   * \param[in] geometry - Geometrical definition of the problem.
   * \param[in] solver_container - Container vector with all the solutions.
   * \param[in] conv_numerics - Description of the numerical method.
   * \param[in] visc_numerics - Description of the numerical method.
   * \param[in] config - Definition of the particular problem.
   * \param[in] val_marker - Surface marker where the boundary condition is applied.
   */
  void BC_Inlet(CGeometry* geometry, CSolver** solver_container, CNumerics* conv_numerics, CNumerics* visc_numerics,
                CConfig* config, unsigned short val_marker) override;

  /*!
   * \brief Impose the (received) conjugate heat variables.
   * \param[in] geometry - Geometrical definition of the problem.
   * \param[in] solver_container - Container vector with all the solutions.
   * \param[in] numerics - Description of the numerical method.
   * \param[in] config - Definition of the particular problem.
   * \param[in] val_marker - Surface marker where the boundary condition is applied.
   */
  void BC_ConjugateHeat_Interface(CGeometry* geometry, CSolver** solver_container, CNumerics* numerics, CConfig* config,
                                  unsigned short val_marker) override;

  /*!
   * \brief Compute the spatial integration using the CScalarFlux_Flamelet edge kernel, which adds
   *        the preferential diffusion terms to the species convection and diffusion.
   * \param[in] geometry - Geometrical definition of the problem.
   * \param[in] solver_container - Container vector with all the solutions.
   * \param[in] config - Definition of the particular problem.
   * \param[in] iMesh - Index of the mesh in multigrid computations.
   */
  void Upwind_Residual(CGeometry* geometry, CSolver** solver_container, CNumerics** numerics_container,
                       CConfig* config, unsigned short iMesh) final;

  /*!
   * \brief Obtain the overall flame thickness value.
   * \return flame thickness value.
   */
  su2double GetFlameThickness() const override {return global_flame_thickness;}
};
