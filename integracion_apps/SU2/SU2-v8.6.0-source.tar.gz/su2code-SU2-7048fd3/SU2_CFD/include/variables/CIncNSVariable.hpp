/*!
 * \file CIncNSVariable.hpp
 * \brief Class for defining the variables of the incompressible
          Navier-Stokes solver.
 * \author F. Palacios, T. Economon
 * \version 8.6.0 "Harrier"
 *
 * SU2 Project Website: https://su2code.github.io
 *
 * The SU2 Project is maintained by the SU2 Foundation
 * (http://su2foundation.org)
 *
 * Copyright 2012-2026, SU2 Contributors (cf. AUTHORS.md)
 *
 * SU2 is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * SU2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with SU2. If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#include "CIncEulerVariable.hpp"

/*!
 * \class CIncNSVariable
 * \brief Class for defining the variables of the incompressible Navier-Stokes solver.
 * \ingroup Navier_Stokes_Equations
 * \author F. Palacios, T. Economon, T. Albring
 */
class CIncNSVariable final : public CIncEulerVariable {
private:
  VectorType Tau_Wall;        /*!< \brief Magnitude of the wall shear stress from a wall function. */
  VectorType DES_LengthScale; /*!< \brief DES Length Scale. */
  VectorType lesMode;        /*!< \brief Sensor for local simulation mode (0=RANS, 1=LES).*/
  const bool Energy;          /*!< \brief Flag for Energy equation in incompressible flows. */
  MatrixType MassDiffusivity; /*!< \brief (nPoint, nSpecies+1) laminar mass diffusivities, evaluated by the fluid model (Cantera). */

public:
  /*!
   * \brief Constructor of the class.
   * \param[in] pressure - value of the pressure.
   * \param[in] velocity - Value of the flow velocity (initialization value).
   * \param[in] temperature - Value of the temperature (initialization value).
   * \param[in] npoint - Number of points/nodes/vertices in the domain.
   * \param[in] ndim - Number of dimensions of the problem.
   * \param[in] nvar - Number of variables of the problem.
   * \param[in] config - Definition of the particular problem.
   */
  CIncNSVariable(su2double pressure, const su2double *velocity, su2double temperature,
                 unsigned long npoint, unsigned long ndim, unsigned long nvar, const CConfig *config);

  /*!
   * \brief Store the laminar mass diffusivity of a species, which the species solver reads.
   * \param[in] iPoint - Point index.
   * \param[in] val_diffusivity - Mass diffusivity.
   * \param[in] val_ivar - Species index, the remainder species included.
   */
  inline void SetMassDiffusivity(unsigned long iPoint, su2double val_diffusivity, unsigned short val_ivar) {
    MassDiffusivity(iPoint, val_ivar) = val_diffusivity;
  }

  /*!
   * \brief Get the laminar mass diffusivity of a species stored by the flow solver.
   */
  inline su2double GetDiffusivity(unsigned long iPoint, unsigned short val_ivar) const override {
    return MassDiffusivity(iPoint, val_ivar);
  }

  /*!
   * \brief Set the laminar viscosity.
   */
  inline void SetLaminarViscosity(unsigned long iPoint, su2double laminarViscosity) override {
    Primitive(iPoint, indices.LaminarViscosity()) = laminarViscosity;
  }

  /*!
   * \overload
   * \param[in] eddy_visc - Value of the eddy viscosity.
   */
  inline void SetEddyViscosity(unsigned long iPoint, su2double eddy_visc) override {
    Primitive(iPoint, indices.EddyViscosity()) = eddy_visc;
  }

  /*!
   * \brief Get the laminar viscosity of the flow.
   * \return Value of the laminar viscosity of the flow.
   */
  inline su2double GetLaminarViscosity(unsigned long iPoint) const override {
    return Primitive(iPoint, indices.LaminarViscosity());
  }

  /*!
   * \brief Get the eddy viscosity of the flow.
   * \return The eddy viscosity of the flow.
   */
  inline su2double GetEddyViscosity(unsigned long iPoint) const override {
    return Primitive(iPoint, indices.EddyViscosity());
  }

  /*!
   * \brief Set the thermal conductivity.
   */
  inline void SetThermalConductivity(unsigned long iPoint, su2double thermalConductivity) override {
    Primitive(iPoint, indices.ThermalConductivity()) = thermalConductivity;
  }

  /*!
   * \brief Get the thermal conductivity of the flow.
   * \return Value of the laminar viscosity of the flow.
   */
  inline su2double GetThermalConductivity(unsigned long iPoint) const override {
    return Primitive(iPoint, indices.ThermalConductivity());
  }

  /*!
   * \brief Set all the primitive variables for incompressible flows
   */
  bool SetPrimVar(unsigned long iPoint, su2double eddy_visc, su2double turb_ke, CFluidModel *FluidModel, const su2double *scalar = nullptr);
  using CVariable::SetPrimVar;

  /*!
   * \brief Set the value of the wall shear stress computed by a wall function.
   */
  inline void SetTau_Wall(unsigned long iPoint, su2double tau_wall) override { Tau_Wall(iPoint) = tau_wall; }

  /*!
   * \brief Get the value of the wall shear stress computed by a wall function.
   * \return Value of the wall shear stress computed by a wall function.
   */
  inline su2double GetTau_Wall(unsigned long iPoint) const override { return Tau_Wall(iPoint); }
  inline const VectorType& GetTau_Wall() const { return Tau_Wall; }

  /*!
   * \brief Set the DES Length Scale.
   */
  inline void SetDES_LengthScale(unsigned long iPoint, su2double val_des_lengthscale) override {
    DES_LengthScale(iPoint) = val_des_lengthscale;
  }

  /*!
   * \brief Get the DES length scale
   * \return Value of the DES length Scale.
   */
  inline su2double GetDES_LengthScale(unsigned long iPoint) const override { return DES_LengthScale(iPoint); }

  /*!
   * \brief Set the LES sensor.
   */
  inline void SetLES_Mode(unsigned long iPoint, su2double val_les_mode) override {
    lesMode(iPoint) = val_les_mode;
  }

  /*!
   * \brief Get the LES sensor.
   * \return Value of the LES sensor.
   */
  inline su2double GetLES_Mode(unsigned long iPoint) const override { return lesMode(iPoint); }

};
