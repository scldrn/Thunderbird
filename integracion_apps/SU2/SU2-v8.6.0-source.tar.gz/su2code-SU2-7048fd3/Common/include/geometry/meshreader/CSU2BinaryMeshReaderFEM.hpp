/*!
 * \file CSU2BinaryMeshReaderFEM.hpp
 * \brief Header file for the class CSU2BinaryMeshReaderFEM.
 *        The implementations are in the <i>CSU2BinaryMeshReaderFEM.cpp</i> file.
 * \author T. Economon, E. van der Weide
 * \version 8.6.0 "Harrier"
 *
 * SU2 Project Website: https://su2code.github.io
 *
 * The SU2 Project is maintained by the SU2 Foundation
 * (http://su2foundation.org)
 *
 * Copyright 2012-2026, SU2 Contributors (cf. AUTHORS.md)
 *
 * SU2 is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * SU2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with SU2. If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#include "CSU2BinaryMeshReaderBase.hpp"

/*!
 * \class CSU2BinaryMeshReaderFEM
 * \brief Reads a native SU2 binary grid into linear partitions for the finite element solver (FEM).
 * \author T. Economon, E. van der Weide
 */
class CSU2BinaryMeshReaderFEM : public CSU2BinaryMeshReaderBase {
 private:
  /*!
   * \brief Reads the grid points from an SU2 zone into linear partitions across all ranks.
   */
  void ReadPointCoordinates();

  /*!
   * \brief Reads the interior volume elements from one section of an SU2 zone into linear partitions across all ranks.
   */
  void ReadVolumeElementConnectivity();

  /*!
   * \brief Reads the surface (boundary) elements from one section of an SU2 zone into linear partitions across all
   * ranks.
   */
  void ReadSurfaceElementConnectivity();

 public:
  /*!
   * \brief Constructor of the CSU2BinaryMeshReaderFEM class.
   */
  CSU2BinaryMeshReaderFEM(CConfig* val_config, unsigned short val_iZone, unsigned short val_nZone);

  /*!
   * \brief Destructor of the CSU2BinaryMeshReaderFEM class.
   */
  ~CSU2BinaryMeshReaderFEM(void) override;
};
