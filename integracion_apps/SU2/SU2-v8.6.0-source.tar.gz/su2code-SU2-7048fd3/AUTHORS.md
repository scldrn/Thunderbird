# SU2 Authors #

SU2 is developed by a community of voluntary contributors who contribute code, bug reports, documentation, support, etc.

## Original Authors ##

```
Francisco D. Palacios (formerly Stanford University)
Thomas D. Economon    (formerly Stanford University)
Juan J. Alonso                 (Stanford University)
```

## Current Maintainers ##

The SU2 project is maintained by members of the SU2 Foundation (https://su2foundation.org)

```
Thomas D. Economon  - Chairperson
Matteo Pini         - Vice Chairperson
Nijso Beishuizen    - Treasurer
Pedro Gomes         - Development Officer
Giulio Gori         - Secretary
Nitish Anand        - Editorial Officer
Edwin van der Weide - Events Officer
```

in collaboration with the following main contributors and research teams:

- Prof. Juan J. Alonso's group at Stanford University.
- Prof. Piero Colonna's group at Delft University of Technology.
- Prof. Nicolas R. Gauger's group at Kaiserslautern University of Technology.
- Prof. Alberto Guardone's group at Polytechnic University of Milan.
- Prof. Rafael Palacios' group at Imperial College London.
- Prof. Vincent Terrapon's group at the University of Liege.
- Prof. Edwin van der Weide's group at the University of Twente.
- Lab. of New Concepts in Aeronautics at Tech. Institute of Aeronautics.
- Bosch LLC Research and Technology Center North America


## Individual Contributors ##

(extracted using `git shortlog -s --no-merges`, alphabetical order).
Copyright holders might be the individual person or their respective employer. If no real name is available, the Github user name is listed.

```
Aidan Jungo
Akshay.K.R
Alejandro
Alessandro Gastaldi
Aman uz zaman Baig
Amit Sachdeva
Ana Lourenco
Andrew Burkett
Andrew Wendorff
Angelo Passariello
Aniket C. Aranake
Antonio Rubino
Arne Bachmann
Arne Voß
Ayush Kumar
Beckett Y. Zhou
Benjamin S. Kirk
BlueChips
Brendan Tracey
Brian Munguía
Carsten Othmer
Catarina Garbacz
Charanya Venkatesan-Crome
Christian Bauer
Clark Pederson
Daumantas Kavolis
Dave Taflin
Davide Di Giusto
Eduardo Molina
Edwin van der Weide
Eitan Aberman
Ethan Alan Hereth
Ezgi Orbay Akcengiz
Florian Dittmann
Filip Hahs
Francesco Poli
Francisco D. Palacios
Gaurav Bansal
Giacomo Baldan
Giulio Gori
Guillaume Bâty
Harichand M V
HL Kline
HL Zhi
IndianaStokes
J. Sinsay
JSmith36
Jacob Needels
Jairo Paes Cavalcante Filho
Jason Howison
Jayant Mukhopadhaya
Jeffrey van Oostrom
Jesse Li
Jessie Lauzon
João Loureiro
Johannes Blühdorn
JonathanSmith1936
Joseph Signorelli
Joshua A. Kelly
Josy P. Pullockara
Kedar Naik
Kürşat Yurt
LaSerpe
Lennaert Tol
Liang Cheng
Lisa Kusch
Matteo Pini
Max Aehle
Max Le
Max Sagebaum
Michele Gaffuri
Mickael Philit
Mladen Banovic
Mor
Nat-1
Nicola Fonzi
Nijso Beishuizen
Ole Burghardt
Patrick Mischke
Paul Urbanczyk
Paul Zhang
Pedro Gomes
Peng Yan
Pete Bachant
Pratyksh Gupta
RaulFeijo55
Ruben Sanchez
Ryan Barrett
SaettaE
Salvatore Vitale
Samet Cakmakcioglu
Scott Imlay
Steffen Schotthöfer
Steven Endres
Sunoh Kang
T. N. Venkatesh
Teus van der Stelt
Thomas D. Economon
Tim Albring
TobiKattmann
Trent Lukaczyk
Vikram Bharadwaj
Vinzenz Götz
VivaanKhatri
Wally Maier
Yair Mor-Yossef
Y. Chandukrishna
Zan Xu
Zcaic
aaronyicongfu
aeroamit
anilvar
band-a-prend
chamsolli
costat
daniel-linton
demanosalvas
dmudiger
erangit
flo
fmpmorgado
garcgutierrez
juliendm
jvanoostrom
mcolonno
minkwankim
padronas
snow54
sravya91
srcopela
tobadavid
vfrancesmolla
Yilun Tan
```
